package lab7;

import java.util.HashSet;

public class Institute {
    
    private String name;
    private HashSet<Faculty> faculties = new HashSet();

    public Institute(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public HashSet<Faculty> getFaculties() {
        return faculties;
    }

    public void setFaculties(HashSet<Faculty> faculties) {
        this.faculties = faculties;
    }
    
    public void addFaculty(Faculty faculty) {
        faculties.add(faculty);
    }
    
    public void delFaculty(Faculty faculty){
        faculties.remove(faculty);
    }
    
}
