package lab7;

public class Student {
    
    private String name;
    private String lastname;
    private int bookNumber;
    private double averageGrade;

    public Student(String name, String lastname, int bookNumber, double averageGrade) {
        this.name = name;
        this.lastname = lastname;
        this.bookNumber = bookNumber;
        this.averageGrade = averageGrade;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getBookNumber() {
        return bookNumber;
    }

    public void setBookNumber(int bookNumber) {
        this.bookNumber = bookNumber;
    }

    public double getAverageGrade() {
        return averageGrade;
    }

    public void setAverageGrade(double averageGrade) {
        this.averageGrade = averageGrade;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.bookNumber;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        if (this.bookNumber != other.bookNumber) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return name + " " + lastname + ", bookNumber=" + bookNumber + ", averageGrade=" + averageGrade;
    }
    
}
