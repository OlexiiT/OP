/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5;

/**
 *
 * @author LioshaT
 */
public class Task21 {
    
    public static double getResult(double a, double b, double c, double d) {
        return 3 * (Math.log(Math.abs(a/b)) + Math.sqrt(Math.cos(c) + Math.pow(Math.E, d)));
    }
    
}
