package lab_14;

public class Lab_14 {

    public static void main(String[] args) {
        
//        Task1.main(args);
//        System.out.println("\n");
        Task3.main(args);
        System.out.println("\n\n");
        Task7.main(args);
    
    }
        
}
