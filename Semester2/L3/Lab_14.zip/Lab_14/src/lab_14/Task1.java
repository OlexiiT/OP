package lab_14;

import java.io.*;

public class Task1 {
    
    public static void main(String[] args) {
        
        System.out.println("---Task1---\n");
        System.out.println(firstLongestString("source.txt"));
        System.out.println("\n---Task1 completed---");
        
    }
    
    static String firstLongestString(String fileName) {
        
        String longestString = "";
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String nextLine; 
            while ((nextLine = br.readLine()) != null) {
                if (nextLine.length() > longestString.length()) {
                    longestString = nextLine;
                }
            }
        } catch (FileNotFoundException ex) {
            System.out.print("Ooops, no such file");
        } catch (IOException ex) {
            System.out.println("Ooops, IO exception");
        } 
        return longestString;
        
    }
    
}
