package lab6;

public interface Task {
    
    double getResult(double a, double b, double c, double d);
    
}
